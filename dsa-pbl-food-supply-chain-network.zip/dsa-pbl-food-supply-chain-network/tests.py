"""16 test cases. Run: python3 tests.py"""
from food_network import avl
from food_network.network import FoodNetwork
from food_network.rbtree import RedBlackTree
from sample_data import load_sample

results = []


def check(tc, ok, actual):
    results.append(ok)
    print(f"{tc} | {'PASS' if ok else 'FAIL'} | {actual}")


def fresh():
    n = FoodNetwork()
    load_sample(n)
    return n


net = fresh()
ok, msg = net.add_batch("Carrots", "Farm Hub A", 150, 12, 5)
check("TC-01", ok and net.find_by_id(9)["product"] == "Carrots", msg)

ok, msg = net.add_batch("", "Farm Hub A", 100, 5, 5)
check("TC-02", (not ok) and "required" in msg, msg)

ok1, m1 = net.add_batch("Beans", "Farm Hub A", 0, 5, 5)
ok2, m2 = net.add_batch("Beans", "Farm Hub A", 100, 5, 11)
check("TC-03", (not ok1) and (not ok2), f"{m1} | {m2}")

net = fresh()
ok, msg = net.add_batch("Tomatoe", "Farm Hub A", 100, 5, 5)
check("TC-04", (not ok) and "duplicate" in msg, msg)

net = fresh()
ok, msg = net.add_batch("Tomatoes", "Warehouse W1", 100, 5, 5)
check("TC-05", ok, msg)

net = fresh()
r2, r99 = net.find_by_id(2), net.find_by_id(99)
check("TC-06", r2["product"] == "Milk Cans" and r99 is None,
      f"#2 -> {r2['product']}; #99 -> {r99}")

r = net.find_by_name("  WHEAT   sacks ")
check("TC-07", r is not None and r["id"] == 3, f"found #{r['id']} {r['product']}")

top = [r["product"] for r in net.most_urgent(3)]
check("TC-08", top == ["Spinach", "Milk Cans", "Tomatoes"], str(top))

score, items = net.load_plan("Farm Hub A", 1000)
total_kg = sum(net.find_by_name(i)["kg"] for i in items)
check("TC-09", score == 32 and total_kg <= 1000,
      f"score {score}, {items}, {total_kg} kg")

res = net.load_plan("Farm Hub A", 50)
check("TC-10", res == (0, []), str(res))

plans = net.exact_load_plans("Farm Hub A", 700)
ok = len(plans) == 3 and all(sum(net.find_by_name(p)["kg"] for p in pl) == 700 for pl in plans)
check("TC-11", ok, f"{len(plans)} plans: {plans}")

route = net.best_route("Farm Hub A", "City Food Bank")
check("TC-12", route[0] == 40, str(route))

check("TC-13", net.nearby_places("Nowhere") is None and net.best_route("Nowhere", "Farm Hub A") == (None, []),
      f"nearby -> {net.nearby_places('Nowhere')}; route -> {net.best_route('Nowhere', 'Farm Hub A')[0]}")

route = net.best_route("Farm Hub A", "Remote Village")
check("TC-14", route == (None, []), str(route))

root, rb = None, RedBlackTree()
for i in range(1, 1024):
    root = avl.insert(root, i, i)
    rb.insert(i, i)
ok = avl.is_balanced(root) and rb.check_rules() and avl.inorder(root) == rb.inorder()
check("TC-15", ok, f"1023 sorted inserts: AVL height {root.height}, "
      f"Red-Black height {rb.height()} (plain BST would be 1023)")

net = fresh()
net.add_batch("Carrots", "Farm Hub A", 150, 12, 5)
names = net.name_index.inorder()
check("TC-16", names == sorted(names) and net.name_index.check_rules(),
      f"{len(names)} product names, sorted order OK")

print(f"\n{sum(results)} of {len(results)} test cases passed")
