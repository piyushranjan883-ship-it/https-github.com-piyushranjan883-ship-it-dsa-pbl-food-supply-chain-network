"""Sample data: eight batches and a small transport network."""


def load_sample(net):
    batches = [
        # product, location, kg, days_left, priority
        ("Tomatoes", "Farm Hub A", 400, 3, 9),
        ("Milk Cans", "Farm Hub A", 300, 2, 10),
        ("Wheat Sacks", "Farm Hub A", 500, 40, 4),
        ("Onions", "Farm Hub A", 200, 15, 5),
        ("Potatoes", "Farm Hub A", 350, 20, 5),
        ("Spinach", "Farm Hub A", 100, 1, 8),
        ("Rice Bags", "Warehouse W1", 600, 90, 3),
        ("Apples", "Warehouse W1", 250, 10, 6),
    ]
    for b in batches:
        net.add_batch(*b)
    roads = [
        ("Farm Hub A", "Village Centre", 8),
        ("Village Centre", "Warehouse W1", 12),
        ("Village Centre", "District Market", 25),
        ("Warehouse W1", "District Market", 14),
        ("Warehouse W1", "Cold Store C1", 9),
        ("Cold Store C1", "City Food Bank", 11),
        ("District Market", "City Food Bank", 20),
        ("Farm Hub A", "Cold Store C1", 30),
    ]
    for a, b, km in roads:
        net.graph.add_road(a, b, km)
    net.graph.add_place("Remote Village")      # not connected to anything
