# Smart Food Supply Chain Collaboration Network

DSA-II (CCSE0301) PBL project. Console program in Python 3 (standard library only).
Partners add food stock batches; the program checks for duplicates, keeps two balanced
tree indexes, suggests truck loads, and finds routes on a small transport network.

| Unit | Used for | File |
|---|---|---|
| 1 - AVL tree, heap | batch-ID index, most urgent batches | `food_network/avl.py`, `network.py` |
| 2 - Graph (BFS, Dijkstra) | nearby places, shortest route | `food_network/graph.py` |
| 3 - Knapsack, LCS | best truck load, duplicate listings | `food_network/planner.py` |
| 4 - Sum of subsets (backtracking) | exact truck load | `food_network/planner.py` |
| 5 - Red-Black tree | product-name index | `food_network/rbtree.py` |

Run: `python3 app.py` (menu) or `python3 app.py demo`. Tests: `python3 tests.py`.
